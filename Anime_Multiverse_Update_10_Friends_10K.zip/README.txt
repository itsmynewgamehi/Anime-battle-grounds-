ANIME MULTIVERSE BATTLEGROUNDS — UPDATE 10 FRIENDS EDITION

OPEN: Extract the ZIP, then double-click index.html. No installation or internet connection required.

ROSTER: 10,000 selectable character builds; 437 named fighters (341 new anime characters), and 9563 playable character variants. The variants share 8 mechanical styles and mix skills, so they are NOT 10,000 independently authored characters.

ANIME PACKS: JoJo's Bizarre Adventure (40), Dragon Ball (36), Jujutsu Kaisen (23), Bleach (36), One Piece (37), Demon Slayer (25), Naruto (29), One Punch Man (20), Hunter x Hunter (20), Fate (14), Frieren (10), Chainsaw Man (11), Black Clover (14), My Hero Academia (15), Attack on Titan (11).

GAME CONTROLS:
WASD / Arrows — move
J or Space — attack
1 2 3 4 — skills
U — ultimate/awakening
Q — dash
E — dodge
B or Shift — hold block
R — reroll Chaos Mode
C — perspective camera toggle
K — offline earn-only item shop
Esc — pause

ROSTER: Use JoJo / Dragon Ball / Bleach / JJK / One Piece filter chips to find fighters quickly, or search by name or series. Other slots can be selected with number jump 1–10,000.

PLAYING WITH FRIENDS: Send friends this ZIP so they can each play offline on their devices. This version does NOT have online matchmaking or real-time multiplayer. To share a browser URL, you can upload index.html to your GitHub repository and enable GitHub Pages via Settings > Pages > Deploy from branch > main / root. Only publish code/assets you have permission to share.

BACKUP: Keep the previous working release intact. Do not overwrite it. Upload this updated index.html and create a new GitHub release (e.g., v0.10-friends).

ASSETS: No copyrighted artwork, music or audio included. Names and original move labels are used as prototype fan-game references.
